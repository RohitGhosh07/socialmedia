import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'package:swipecv/models/image_model.dart';
import '../providers/image_provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final PageController _scrollController = PageController();
  bool _showButtons = false;
  ValueNotifier<double> scaleNotifier = ValueNotifier<double>(1.0);
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppImageProvider>(context, listen: false).loadImages();
    });

    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (!_showButtons) {
          setState(() {
            _showButtons = true;
          });
        }
      } else {
        if (_showButtons) {
          setState(() {
            _showButtons = false;
          });
        }
      }
    });
  }

  getFilterPopup() {
    // get image provider
    final imageProvider = Provider.of<AppImageProvider>(context, listen: false);
    String selectedArea = imageProvider.selectedArea;
    String selectedClub = imageProvider.selectedClub;
    // get areas and clubs from image provider
    List<String> areas = imageProvider.images
        .where((element) {
          if (selectedClub.isNotEmpty) {
            return element.club == selectedClub;
          } else {
            return true;
          }
        })
        .map((e) => e.area ?? '')
        .toSet()
        .toList();
    List<String> clubs = imageProvider.images
        .where((element) {
          if (selectedArea.isNotEmpty) {
            return element.area == selectedArea;
          } else {
            return true;
          }
        })
        .map((e) => e.club ?? '')
        .toSet()
        .toList();
    // Show filter popup
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        backgroundColor: Colors.white,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
        title: const Text('Filter by'),
        children: [
          DefaultTabController(
            length: 2,
            child: Column(
              children: [
                const TabBar(
                  indicatorColor: Colors.black,
                  labelColor: Colors.black,
                  tabs: [
                    Tab(text: 'Area'),
                    Tab(text: 'Club'),
                  ],
                ),
                SizedBox(
                  height: 200, // adjust this value as needed
                  child: TabBarView(
                    children: [
                      ListView.builder(
                        itemCount: areas.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(
                              areas[index],
                              style: TextStyle(
                                fontStyle: (areas[index] == selectedArea)
                                    ? FontStyle.italic
                                    : FontStyle.normal,
                                fontWeight: (areas[index] == selectedArea)
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                            ),
                            onTap: () {
                              // implement your CV filtering logic here
                              imageProvider.selectedArea = areas[index];
                              Navigator.of(context).pop();
                            },
                          );
                        },
                      ),
                      ListView.builder(
                        itemCount: clubs.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(
                              clubs[index],
                              style: TextStyle(
                                fontStyle: (clubs[index] == selectedClub)
                                    ? FontStyle.italic
                                    : FontStyle.normal,
                                fontWeight: selectedClub == clubs[index]
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                            ),
                            onTap: () {
                              // implement your CV filtering logic here
                              imageProvider.selectedClub = clubs[index];
                              Navigator.of(context).pop();
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Reset Button
          TextButton(
            onPressed: () {
              // implement your CV filtering logic here
              imageProvider.selectedArea = '';
              imageProvider.selectedClub = '';
              Navigator.of(context).pop();
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<ImageModel> images = Provider.of<AppImageProvider>(context).images;
    // String searchValue = Provider.of<AppImageProvider>(context).searchValue;
    String selectedArea = Provider.of<AppImageProvider>(context).selectedArea;
    String selectedClub = Provider.of<AppImageProvider>(context).selectedClub;
    final isLoading = Provider.of<AppImageProvider>(context).isLoading;

    if (selectedArea.isNotEmpty) {
      images = images.where((e) => e.area == selectedArea).toList();
    }
    if (selectedClub.isNotEmpty) {
      images = images.where((e) => e.club == selectedClub).toList();
    }

    return Scaffold(
      body: Stack(
        children: [
          if (images.isNotEmpty && !isLoading)
            PageView.builder(
              controller: _scrollController,
              scrollDirection: Axis.vertical,
              itemCount: images.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onDoubleTap: () {
                    // Navigate to ZoomView
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) {
                        return ZoomView(
                          images: images[index],
                        );
                      }),
                    );
                  },
                  onTap: () {
                    // Navigate to ZoomView
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) {
                        return ZoomView(
                          images: images[index],
                        );
                      }),
                    );
                  },
                  child: Image.network(images[index].imgUrl ?? '',
                      fit: BoxFit.fitWidth),
                );
              },
            ),
          if (images.isEmpty && !isLoading)
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error, size: 50),
                  Text('No CV found'),
                ],
              ),
            ),
          if (_showButtons || images.isEmpty)
            Positioned(
              // at the top center
              top: 50,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Search Bar
                  Expanded(
                    child: Container(
                      // width: double.infinity,
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 1,
                            blurRadius: 7,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextField(
                        controller: _searchController,
                        decoration: const InputDecoration(
                          hintText: 'Search Name',
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.search),
                        ),
                        // onChanged: (value) {
                        //   Provider.of<AppImageProvider>(context, listen: false)
                        //       .searchValue = value;
                        // },
                        onEditingComplete: () {
                          FocusScope.of(context).unfocus();
                          Provider.of<AppImageProvider>(context, listen: false)
                              .searchValue = _searchController.text.trim();
                        },
                      ),
                    ),
                  ),
                  // Filter Button
                  GestureDetector(
                    onTap: () => getFilterPopup(),
                    child: Container(
                      height: 40,
                      width: 40,
                      margin: const EdgeInsets.only(right: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 1,
                            blurRadius: 7,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.filter_list),
                    ),
                  ),
                ],
              ),
            ),
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}

class ZoomView extends StatelessWidget {
  const ZoomView({
    super.key,
    required this.images,
  });

  final ImageModel images;

  @override
  Widget build(BuildContext context) {
    final TransformationController controller = TransformationController();

    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              child: GestureDetector(
                onDoubleTap: () {
                  // zoom out or zoom in
                  if (controller.value.getMaxScaleOnAxis() > 1) {
                    controller.value = Matrix4.identity();
                  } else {
                    controller.value = Matrix4.identity()..scale(2.0);
                  }
                },
                child: InteractiveViewer(
                  transformationController: controller,
                  boundaryMargin: const EdgeInsets.all(20.0),
                  minScale: 0.1,
                  maxScale: 2.0,
                  child:
                      Image.network(images.imgUrl ?? '', fit: BoxFit.fitWidth),
                ),
              ),
            ),
            // Pop Button
            Positioned(
              top: 50,
              right: 20,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: const CircleBorder(),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Icon(
                  Icons.close,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
